#!/bin/bash

export ISOFILE=morphos-3.19.iso

# Extract kernel from CD image
7z e ${ISOFILE} mac_ppc32/boot.img

# Start MorphOS at Pegasos hardware emulation
qemu-system-ppc -machine pegasos2 -rtc base=localtime \
  -device ati-vga,guest_hwcursor=true,romfile="" \
  -cdrom ${ISOFILE} -kernel boot.img -serial stdio
