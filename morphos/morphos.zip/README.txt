
MorphOS at Qemu
===============
1. sudo apt -y install qemu-system 7zip-full
2. Download morhos .iso file
3. Edit start.sh, change to have correct iso filename.
4. Run: ./start.sh
5. It will extract kernel from .iso file, and start using PPC G4 hardware emulation.
6. For pegasus hardware emulation, edit and use start2.sh

