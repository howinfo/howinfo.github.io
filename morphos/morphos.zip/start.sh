#!/bin/bash

export ISOFILE=morphos-3.19.iso

# Extract kernel from CD image
7z e ${ISOFILE} mac_ppc32/boot.img

# Start MorphOS at mac99 hardware emulation
qemu-system-ppc -machine mac99,via=pmu -m 512 \
  -vga none -device sm501 \
  -cdrom ${ISOFILE} -boot d \
  -prom-env "boot-device=cd:,\mac_ppc32\boot.img" \
  -bios openbios-qemu.elf -serial stdio
